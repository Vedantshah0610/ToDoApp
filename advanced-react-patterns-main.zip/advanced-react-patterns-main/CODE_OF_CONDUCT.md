Please refer to [kentcdodds.com/conduct/](https://kentcdodds.com/conduct/)
